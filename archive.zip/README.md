# bastomat
Sistem za navodnjavanje baste
